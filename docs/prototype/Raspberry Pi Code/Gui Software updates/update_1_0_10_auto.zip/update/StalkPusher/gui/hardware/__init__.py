'''
__init__.py.py created by Witold on 2/1/2017 under the pygametrial project
'''