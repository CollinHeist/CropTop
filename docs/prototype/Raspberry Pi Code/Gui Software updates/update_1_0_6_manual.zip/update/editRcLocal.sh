#!/bin/bash
echo Start Edit
sudo sed -i  "s/sudo python3 \/home\/pi\/Desktop\/cropDevice\/main\/cropDev.py/sudo python3 \/home\/pi\/Desktop\/StalkPusher\/gui\/main\/cropDev.py/" /etc/rc.local
echo Edit finished.
