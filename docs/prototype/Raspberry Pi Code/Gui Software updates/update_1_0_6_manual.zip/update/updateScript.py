import os
import subprocess
'''
This is the update script for the Update System 1
'''
#helpers
def osCommand(command):
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
    output = process.communicate()[0]
def readSettingFromFile(file_path):
    import json
    with open(file_path, 'r') as data_file:
        data = json.load(data_file)
        return data

def saveSettingsObject(setting_file_path, settingsObject):
    import json
    with open(setting_file_path, 'r+') as data_file:
        data_file.seek(0)
        json.dump(settingsObject, data_file,indent=4)
        data_file.truncate()

answer = input('Do you wish to proceed with update? (y/n)')
if answer == 'y':
    #First, read setting file
    oldAppData = readSettingFromFile('/home/pi/Desktop/cropDevice/main/appData.json')
    #Change the dictionary version
    oldAppData['version'] = '1.0.6'
    #Remove the old software
    osCommand('rm -r /home/pi/Desktop/cropDevice')
    #Copy the new software
    osCommand('cp -r /home/pi/Documents/cropDevUsb/update/StalkPusher /home/pi/Desktop')
    #Overwrite the new software appData file with old one that has new version number
    saveSettingsObject('/home/pi/Desktop/StalkPusher/gui/main/appData.json', oldAppData)

    for path, subdirs, files in os.walk('/home/pi/Desktop/StalkPusher'):
        osCommand('chmod 777 ' + path)
        for name in files:
            filePath = os.path.join(path, name)
            osCommand('chmod 777 ' + filePath)
    answer = input('Finished. Press any key to exit.')
